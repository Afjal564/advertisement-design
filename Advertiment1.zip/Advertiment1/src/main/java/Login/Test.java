package Login;

import java.util.*;

public class Test {
    public static void main(String[] args) {
        int[] arr = {9,0,2,1,9,4,4,1,0,2};        
        Set<Integer> uniqueSet = new HashSet<>();        
        for (int i = 0; i < arr.length; i++) {
            if (!uniqueSet.contains(arr[i])) {
            	uniqueSet.add(arr[i]);
            }
        }
        int[] uniqueArr = new int[uniqueSet.size()];
        
        int i = 0;
        for (int element : uniqueSet) {
            uniqueArr[i++] = element;
        }        
        System.out.println(Arrays.toString(uniqueArr));
    }
}
